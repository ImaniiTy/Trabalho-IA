viewDistance = 3
reward_multiplier = 4
maxHaliteToMove = 150
maxHaliteToReturn = 850
death_penality = -3000
objective_reward = 5000
gamma = .85