viewDistance = 3
reward_multiplier = 10
maxHaliteToMove = 150
maxHaliteToReturn = 850
gamma = .85